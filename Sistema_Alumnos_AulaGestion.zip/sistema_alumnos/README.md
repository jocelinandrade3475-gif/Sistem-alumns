# AulaGestión — Sistema de registro de alumnos

Aplicación web académica desarrollada con Python, Flask, SQLite, HTML y CSS. Incluye operaciones CRUD: crear, consultar listado, consultar detalle, editar y eliminar registros.

## Ejecutar localmente

1. Instala Python 3.10 o superior.
2. En la carpeta del proyecto ejecuta: `pip install -r requirements.txt`
3. Ejecuta: `python app.py`
4. Abre `http://127.0.0.1:5000`.

La base de datos `alumnos.db` se crea automáticamente al iniciar la aplicación.

## Despliegue

El proyecto está preparado para iniciar con Gunicorn en Railway. Sube todos los archivos de esta carpeta a un repositorio GitHub, crea un proyecto nuevo en Railway desde ese repositorio y despliega. Para conservar la base SQLite entre despliegues, configura un volumen persistente y adapta `DB_PATH` a una ruta dentro del volumen. Para uso real con múltiples instancias se recomienda PostgreSQL.

## Rutas principales
- `/` listado de alumnos
- `/alumno/nuevo` alta
- `/alumno/<id>` consulta individual
- `/alumno/<id>/editar` modificación
- `/alumno/<id>/eliminar` eliminación (POST)
