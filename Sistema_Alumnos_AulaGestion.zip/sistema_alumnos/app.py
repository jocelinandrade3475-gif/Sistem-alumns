from flask import Flask, render_template, request, redirect, url_for, flash, abort
import sqlite3
from pathlib import Path

app = Flask(__name__)
app.secret_key = 'cambia-esta-clave-antes-de-produccion'
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / 'alumnos.db'


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    with get_db() as db:
        db.execute('''CREATE TABLE IF NOT EXISTS alumnos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            apellido TEXT NOT NULL,
            correo TEXT NOT NULL UNIQUE,
            grado TEXT NOT NULL
        )''')


@app.route('/')
def index():
    with get_db() as db:
        alumnos = db.execute('SELECT * FROM alumnos ORDER BY id DESC').fetchall()
    return render_template('index.html', alumnos=alumnos)


@app.route('/alumno/nuevo', methods=['GET', 'POST'])
def nuevo():
    if request.method == 'POST':
        datos = [request.form.get(k, '').strip() for k in ('nombre', 'apellido', 'correo', 'grado')]
        if not all(datos):
            flash('Completa todos los campos.', 'error')
            return render_template('formulario.html', alumno=None)
        try:
            with get_db() as db:
                cur = db.execute('INSERT INTO alumnos (nombre, apellido, correo, grado) VALUES (?, ?, ?, ?)', datos)
                alumno_id = cur.lastrowid
            flash('Alumno agregado correctamente.', 'success')
            return redirect(url_for('detalle', alumno_id=alumno_id))
        except sqlite3.IntegrityError:
            flash('Ese correo ya está registrado. Utiliza otro.', 'error')
    return render_template('formulario.html', alumno=None)


@app.route('/alumno/<int:alumno_id>')
def detalle(alumno_id):
    with get_db() as db:
        alumno = db.execute('SELECT * FROM alumnos WHERE id = ?', (alumno_id,)).fetchone()
    if alumno is None:
        abort(404)
    return render_template('detalle.html', alumno=alumno)


@app.route('/alumno/<int:alumno_id>/editar', methods=['GET', 'POST'])
def editar(alumno_id):
    with get_db() as db:
        alumno = db.execute('SELECT * FROM alumnos WHERE id = ?', (alumno_id,)).fetchone()
    if alumno is None:
        abort(404)
    if request.method == 'POST':
        datos = [request.form.get(k, '').strip() for k in ('nombre', 'apellido', 'correo', 'grado')]
        if not all(datos):
            flash('Completa todos los campos.', 'error')
            return render_template('formulario.html', alumno=alumno)
        try:
            with get_db() as db:
                db.execute('UPDATE alumnos SET nombre=?, apellido=?, correo=?, grado=? WHERE id=?', (*datos, alumno_id))
            flash('Información actualizada.', 'success')
            return redirect(url_for('detalle', alumno_id=alumno_id))
        except sqlite3.IntegrityError:
            flash('Ese correo ya pertenece a otro registro.', 'error')
    return render_template('formulario.html', alumno=alumno)


@app.route('/alumno/<int:alumno_id>/eliminar', methods=['POST'])
def eliminar(alumno_id):
    with get_db() as db:
        db.execute('DELETE FROM alumnos WHERE id = ?', (alumno_id,))
    flash('Registro eliminado.', 'success')
    return redirect(url_for('index'))


@app.errorhandler(404)
def no_encontrado(_):
    return render_template('404.html'), 404


init_db()

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
